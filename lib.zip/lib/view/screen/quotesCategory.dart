import 'dart:math';

import 'package:flutter/material.dart';
import 'package:quote_app/view/screen/quotesHomePage.dart';

import '../../controller/helper/QuotesGlobal.dart';

class QuotesCategory extends StatefulWidget {
  const QuotesCategory({Key? key}) : super(key: key);

  @override
  State<QuotesCategory> createState() => _QuotesCategoryState();
}

class _QuotesCategoryState extends State<QuotesCategory> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Category"),
        centerTitle: true,
        backgroundColor: Colors.black54,
      ),
      body: Center(
          child: Column(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          ElevatedButton(
              onPressed: () {
                setState(() {
                  Global.endpoint = "age";
                });
                Navigator.push(
                    context, MaterialPageRoute(builder: (context) => QuotesHomePage()));
              },
              child: Text("age")),
          ElevatedButton(
              onPressed: () {
                setState(() {
                  Global.endpoint = "alone";
                });
                Navigator.push(
                    context, MaterialPageRoute(builder: (context) => QuotesHomePage()));
              },
              child: Text("alone")),
          ElevatedButton(
              onPressed: () {
                setState(() {
                  Global.endpoint = "amazing";
                });
                Navigator.push(
                    context, MaterialPageRoute(builder: (context) => QuotesHomePage()));
              },
              child: Text("amazing")),
          ElevatedButton(
              onPressed: () {
                setState(() {
                  Global.endpoint = "anger";
                });
                Navigator.push(
                    context, MaterialPageRoute(builder: (context) => QuotesHomePage()));
              },
              child: Text("anger")),
          ElevatedButton(
              onPressed: () {
                setState(() {
                  Global.endpoint = "art";
                });
                Navigator.push(
                    context, MaterialPageRoute(builder: (context) => QuotesHomePage()));
              },
              child: Text("art")),
        ],
      )),
      );
      // body: ListView.builder(
      //   padding: EdgeInsets.all(10),
      //   itemCount: Global.category.length,
      //   itemBuilder: (BuildContext context, int index){
      //     return Container();
      //   },
      // ),
  }

}
