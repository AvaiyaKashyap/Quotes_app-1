import 'package:flutter/material.dart';

class QuotesDetailPage extends StatefulWidget {
  const QuotesDetailPage({Key? key}) : super(key: key);

  @override
  State<QuotesDetailPage> createState() => _QuotesDetailPageState();
}

class _QuotesDetailPageState extends State<QuotesDetailPage> {
  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}
